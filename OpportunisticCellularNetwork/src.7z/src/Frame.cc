

#include "Frame.h"

Frame::Frame() {
    //this->setName("frame");
}
