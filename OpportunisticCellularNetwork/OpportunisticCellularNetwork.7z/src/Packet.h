/*
 * Packet.h
 *
 *  Created on: 29 gen 2020
 *      Author: lore
 */

#ifndef PACKET_H_
#define PACKET_H_

#include <omnetpp.h>
#include "PacketMessage_m.h"

using namespace omnetpp;

class Packet {
  public:
    int userId;
    simtime_t arrivalTime;
    int sizeBytes;

  public:
    Packet();
    virtual ~Packet();
    PacketMessage* toPacketMessage();
};

#endif /* PACKET_H_ */
