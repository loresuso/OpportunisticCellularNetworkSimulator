#include "Antenna.h"
#include <string.h>
#include <algorithm>
#include "PacketMessage_m.h"
#include "Frame.h"

Define_Module(Antenna);

bool compareUserInfos(const UserInfo& ui1, const UserInfo& ui2){
    return ui1.cqi > ui2.cqi;
}

void Antenna::initialize()
{
    numUsers = par("numUsers");
    isUniform = par("isUniform");
    userInfos = vector<UserInfo>(numUsers);

    globalThroughputSignalId = registerSignal("globalThroughput");
    usedRBsSignalId = registerSignal("usedRBs");
    globalQueuesLengthSignalId = registerSignal("globalQueuesLength");
    responseTimeSignalId = registerSignal("responseTime");

    for(int i = 0; i < numUsers; i++){
        userInfos[i].id = i;
    }

    beep = new cMessage("timeSlotStart");
    scheduleAt( simTime() + timeSlotPeriod, beep);
    EV << "Antenna initialized \n";
}

void Antenna::handleMessage(cMessage *msg)
{
    if(strcmp(msg->getFullName(), "newPacket") == 0)
        enqueue(msg);
    else if(strcmp(msg->getFullName(), "timeSlotStart") == 0)
        handleTimeSlot();
}

void Antenna::enqueue(cMessage *msg){
    EV << "ENQUEUE" << endl;
    Packet p;
    PacketMessage* msg_ = (PacketMessage*)(msg);
    p.userId = msg_->getUserId();
    p.sizeBytes = msg_->getSizeBytes();
    p.arrivalTime = (simtime_t)msg_->getArrivalTime();
    cancelAndDelete(msg_);
    for(int i = 0; i < numUsers; ++i){
        if(userInfos[i].id == p.userId){
            userInfos[i].q.push(p);
            break;
        }
    }
}

void Antenna::handleTimeSlot(){
    int freeRBs = 25;
    int bytesPerFrame = 0;
    Frame frame;
    // compute cqis for each user
    generateCQIs();
    //ordina
    sort(userInfos.begin(), userInfos.end(), compareUserInfos);
    //componi
    for(int i = 0; i < numUsers; ++i){
        UserInfo& user = userInfos[i];
        if(freeRBs <= 0)
            break;
        int freeBytes = freeRBs * lookUpCQI[user.cqi];
        int numPackets = user.q.size();
        int occupiedBytes = 0;
        for(int i = 0; i < numPackets; ++i){
            int packetSize = user.q.front().sizeBytes;
            if(packetSize < freeBytes){
                EV << " POP ELEMENTO " << endl;
                freeBytes -= packetSize;
                occupiedBytes += packetSize;
                bytesPerFrame += packetSize;
                Packet tmp = user.q.front();
                frame.push_back(tmp);
                user.q.pop();
            }
            else
                break;
        }
        freeRBs -= occupiedBytes / lookUpCQI[user.cqi];
        if(occupiedBytes % lookUpCQI[user.cqi])
            freeRBs--;
    }

    // send frame out
    sendFrame(frame);

    // compute throughput
    emit(globalThroughputSignalId, bytesPerFrame);
    EV << "GLOBAL THROUGHPUT: " << bytesPerFrame << "B/ts" << endl;

    // used rRBs
    emit(usedRBsSignalId, 25 - freeRBs);
    EV << "USED RB: " << 25 - freeRBs << endl;

    // compute queues statistics
    for(int i = 0; i < numUsers; ++i){
        emit(globalQueuesLengthSignalId, (double)userInfos[i].q.size());
        EV << "QUEUE LENGTH USER: " << userInfos[i].q.size() << endl;
    }

    // compute response time statistics
    for(int i = 0; i < frame.size(); ++i)
        emit(responseTimeSignalId, simTime() - frame[i].arrivalTime);

    // schedule next timeslotStart
    scheduleAt( simTime() + timeSlotPeriod, beep);
}



void Antenna::generateCQIs(){
    for(int i = 0; i < numUsers; ++i){
        if(isUniform)
            userInfos[i].cqi = intuniform(1, 15, i + 2*numUsers);
        else {
            double successProbability = (double) ( (double)(userInfos[i].id +1) / (double) (numUsers+2) ) ;
            userInfos[i].cqi = 1 + (binomial(14, successProbability, i + 2*numUsers));
        }
    }
}


void Antenna::sendFrame(Frame& frame){
    size_t frameSize = frame.size();
    for(auto i = 0; i < frameSize; ++i){
        Packet& p = frame[i];
        send(p.toPacketMessage(),"out",p.userId);
    }
}

















