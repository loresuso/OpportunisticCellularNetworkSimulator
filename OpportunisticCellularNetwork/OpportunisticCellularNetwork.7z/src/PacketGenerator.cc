//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "PacketGenerator.h"
#include "PacketMessage_m.h"
#include <string.h>

int PacketGenerator::nextId = 0;

Define_Module(PacketGenerator);

PacketGenerator::PacketGenerator(){
    beep = new cMessage("beep");
}

void PacketGenerator::initialize()
{
    numUsers = par("numUsers");
    isVoIP = par("isVoIP");
    userId = PacketGenerator::nextId;
    PacketGenerator::nextId = (PacketGenerator::nextId + 1) % numUsers;
    EV << "PacketGenerator initialized for userId: " << userId << '\n';
    // generating first message
    if(isVoIP) {
        isOn = false;
        EV << "Sono voip" << endl;
        scheduleAt( simTime(),  beep); // schedule the first on or off
        nextVoIP = new cMessage("nextVoIPmsg");
        meanExp = 0;
    }
    else { // basic scenarios
        isOn = false;
        meanExp = par("meanExp");
        scheduleAt( simTime(),  beep);
        nextVoIP = 0;
    }

}



void PacketGenerator::handleMessage(cMessage *msg)
{
    if(strcmp(msg->getFullName(), "beep") == 0){
        if(!isVoIP){ // basic scenarios
            sendNewPacket();
            simtime_t time = exponential(meanExp, userId);
            scheduleAt( simTime() + time, beep);
        }
        else {
            if(isOn){
                cancelEvent(nextVoIP);
                isOn = false;
                EV << "passo allo stato off" << endl;
            }
            else {
                isOn= true;
                scheduleAt( simTime() + nextPacketTime, nextVoIP);
                sendNewPacket();
                EV << "passo allo stato on" << endl;
            }

            scheduleAt( simTime() + exponential(meanOnOffTime, userId),  beep);
        }
    }
    else if(strcmp(msg->getFullName(), "nextVoIPmsg") == 0){
        scheduleAt( simTime() + nextPacketTime, nextVoIP);
        sendNewPacket();
    }
}

void PacketGenerator::sendNewPacket(){
    PacketMessage* packetMessage = new PacketMessage("newPacket");
    packetMessage->setUserId(userId);
    packetMessage->setArrivalTime(simTime());
    int packetSize = intuniform(1, 75, userId + numUsers);
    EV << "INVIATO NUOVO PACCHETTO PER USER " << userId << endl << " DIMENSIONE " << packetSize << endl;
    packetMessage->setSizeBytes(packetSize); // uniform
    send(packetMessage, "out");
}

PacketGenerator::~PacketGenerator(){
    cancelAndDelete(beep);
    if(isVoIP)
        cancelAndDelete(nextVoIP);
}
