//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __OPPORTUNISTICCELLULARNETWORK_ANTENNA_H_
#define __OPPORTUNISTICCELLULARNETWORK_ANTENNA_H_

#include <omnetpp.h>
#include <vector>
#include <queue>
#include "Packet.h"
#include "Frame.h"

using namespace std;
using namespace omnetpp;


struct UserInfo {
    int cqi;
    int id;
    queue<Packet> q;
};



class Antenna : public cSimpleModule
{
  private:
    const int lookUpCQI[16] = {0, 3, 3, 6, 11, 15, 20, 25, 36, 39, 50, 63, 72, 80, 93, 93};

  protected:
    simsignal_t globalThroughputSignalId;
    simsignal_t usedRBsSignalId;
    simsignal_t globalQueuesLengthSignalId;
    simsignal_t responseTimeSignalId;
    bool isUniform;
    const simtime_t timeSlotPeriod = 0.001; // 1ms timeslot
    cMessage* beep;
    int numUsers;
    vector<UserInfo> userInfos;
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
    virtual void enqueue(cMessage *msg);
    virtual void handleTimeSlot();
    virtual inline void generateCQIs();
    virtual void sendFrame(Frame& frame);
};

#endif
