/*
 * Frame.cc
 *
 *  Created on: 30 gen 2020
 *      Author: lore
 */

#include "Frame.h"

Frame::Frame() {
    //this->setName("frame");
}
